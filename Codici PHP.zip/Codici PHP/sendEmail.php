<?php
require 'C:/xampp/htdocs/IoT_prog/PHPMailer-master/src/PHPMailer.php';
require 'C:/xampp/htdocs/IoT_prog/PHPMailer-master/src/SMTP.php';
require 'C:/xampp/htdocs/IoT_prog/PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_POST['message'])) {
    die("Errore: Nessun messaggio ricevuto");
}

$message = $_POST['message'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sensori_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT email FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $email = $row["email"];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "Errore: Indirizzo email non valido ({$email})<br>";
            continue;
        }

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'emanuela.lubrano22@gmail.com'; // Sostituisci con la tua email
            $mail->Password = 'uwdr iqfz yyqq vfjc'; // Sostituisci con la tua password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
            
            $mail->setFrom('emanuela.lubrano22@gmail.com', 'MAGAZZINO SMART');
            $mail->addAddress($email);
            
            $mail->isHTML(true);
            $mail->Subject = 'DISPONIBILITA\'';
            $mail->Body    = $message;
            
            $mail->send();
            echo 'Email inviata correttamente a ' . $email . '<br>';
        } catch (Exception $e) {
            echo "Errore nell'invio dell'email a {$email}: {$mail->ErrorInfo}<br>";
        }
    }
} else {
    echo "0 results";
}
$conn->close();
?>
