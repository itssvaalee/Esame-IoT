<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "sensori_db";

// Crea una connessione
$conn = mysqli_connect($hostname, $username, $password, $database);

// Controlla la connessione
if (!$conn) {
    die("Connessione fallita: " . mysqli_connect_error());
}

echo("Connesso correttamente al databse!");

if (isset($_POST["temperatura"]) && isset($_POST["umidità"])&& isset($_POST["cella_codice"]) && isset($_POST["presenza"])) {
    $t = $_POST["temperatura"];
    $h = $_POST["umidità"];
    $p = $_POST["presenza"];
    $c = $_POST["cella_codice"];

    // Valida gli input
    if (is_numeric($t) && is_numeric($h) && is_numeric($c)&& is_numeric($p)) {
        // Prepara gli statement
        $stmt_dht11 = $conn->prepare("INSERT INTO dht11 (temperatura, umidità) VALUES (?, ?)");
        $stmt_ultrasonic = $conn->prepare("INSERT INTO ultrasonic (cella_codice, presenza) VALUES (?, ?)");

        if ($stmt_dht11 && $stmt_ultrasonic) {
            // Bind dei parametri
            $stmt_dht11->bind_param("dd", $t, $h);
            $stmt_ultrasonic->bind_param("ii", $c, $p);

            // Esegui le query
            if ($stmt_dht11->execute() && $stmt_ultrasonic->execute()) {
                echo("\nNuova riga creata correttamente! ");
            } else {
                echo "Errore nell'esecuzione degli statement: " . $conn->error;
            }

            // Chiudi gli statement
            $stmt_dht11->close();
            $stmt_ultrasonic->close();
        } else {
            echo "Errore nella preparazione degli statement: " . $conn->error;
        }
    } else {
        echo "Invalid dati sensore.";
    }
} else {
    echo "Mancanza dati sensore.";
}

// Chiudi la connessione
$conn->close();

?>
