<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sensori_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM ultrasonic WHERE presenza = 1"; 
$result = $conn->query($sql);

if ($result->num_rows > 0) {
echo "Qua vengono mostrati tutte le righe di quelli che hanno presenza =1, ossia dove c'è il prodotto\n";

    while ($row = $result->fetch_assoc()) {
        echo "\nID: " . $row["ID"] . " - PRESENZA: " . $row["presenza"] . "\n";
    }
} else {
    echo "No items available";
}
$conn->close();
?>

